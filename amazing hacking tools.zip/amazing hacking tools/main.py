from time import sleep
import os
import subprocess


selection = ""
loaded_assets = []

script_dir = os.path.dirname(os.path.abspath(__file__))

version = "1.0 BETA"






def check_for_assets():
    print("checking for assets...")
    sleep(0.5)
    file_path = script_dir + "\\assets\\system\\downloader.py"
    if os.path.exists(file_path):
        print("assets found")
        sleep(0.5)
        print("initializing assets...")
        sleep(1)
        initialize_assets()
    else:
        print("assets not found")
        print("please download assets from github to continue...")
        terminate()

def initialize_assets():


    folder_path = script_dir + "\\assets\\hacks"
    files = os.listdir(folder_path)

    for file in files:
        print("loading "+file)
        loaded_assets.append(file)
        sleep(1)
    loaded_assets.append("exit_programm")
        
    print("loading complete")
    print(loaded_assets)
    print("loaded "+str(len(loaded_assets))+" assets")
    


def terminate():
    print("exiting...")
    sleep(3)
    exit()





def main():
    print("~~~~~MENU~~~~~")
    for i in range(len(loaded_assets)):
        sleep(0.5)
        print(str(i) + ". " + loaded_assets[i])
        
    print("\n\ntype a number to select")
    selection = input(">>>>>")
    
    sleep(1)
    if loaded_assets[int(selection)] == "exit_programm":
        terminate()
    else:
        print("checking file existence...")
        if os.path.exists(os.path.join(script_dir, "assets", "hacks", loaded_assets[int(selection)])):
            print("file exists!")
            if input("want to run " + loaded_assets[int(selection)] + "?\nY/N") == "Y":
                print("opening " + loaded_assets[int(selection)] + "...")
                sleep(1)
                subprocess.run(["python", os.path.join(script_dir, "assets", "hacks", loaded_assets[int(selection)])])  # Fixed subprocess.run arguments
                main()
            
        else:
            print("file does not exist. Returning to menu...")
            sleep(3)
            main()
    

















sleep(1)

print("\n\n\n\n\nversion: "+version)
print("starting...")
check_for_assets()
main()



