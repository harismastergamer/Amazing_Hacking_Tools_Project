from time import sleep

print("Try this:")
sleep(1)
print("u have 60 seconds to read that!!!")
sleep(5)
print("go find the assets folder (it is in the same folder as the script)\nThen go to hacks and make a little python script, something that just prints something or something else, IDK, JUST DON'T FORGOT TO ADD DELAYS\nthen restart this script and see the menu (;)")
sleep(60)